import requests
from google.adk.tools import ToolContext
from google.adk.tools.agent_tool import AgentTool

LOCATION_COORDINATES = {
    "sunnyvale": "37.3688,-122.0363",
    "san francisco": "37.7749,-122.4194",
    "lake tahoe": "39.0968,-120.0324"
}

def get_live_weather_forecast(location: str) -> dict:
    """Gets the current, real-time weather forecast for a specified location in the US.
    
    Args:
        location: The city name, e.g., "San Francisco".
    """
    normalized_location = location.lower()
    coords_str = next((val for key, val in LOCATION_COORDINATES.items() if key in normalized_location), None)
    if not coords_str:
        return {"status": "error", "message": f"No coordinates for {location}"}

    try:
        headers = {"User-Agent": "Local ADK Project"}
        points_resp = requests.get(f"https://api.weather.gov/points/{coords_str}", headers=headers).json()
        forecast_url = points_resp['properties']['forecast']
        forecast_resp = requests.get(forecast_url, headers=headers).json()
        current_period = forecast_resp['properties']['periods'][0]
        return {
            "status": "success",
            "temperature": f"{current_period['temperature']}°{current_period['temperatureUnit']}",
            "forecast": current_period['detailedForecast']
        }
    except Exception as e:
        return {"status": "error", "message": str(e)}
    
async def call_db_agent(
question: str,
tool_context: ToolContext,
):
    """
    Use this tool FIRST to connect to the database and retrieve a list of places, like hotels or landmarks.
    """
    # Import locally to prevent circular dependency loop
    from agents import db_agent
    print("--- TOOL CALL: call_db_agent ---")
    agent_tool = AgentTool(agent=db_agent)
    db_agent_output = await agent_tool.run_async(
        args={"request": question}, tool_context=tool_context
    )
    # Store the retrieved data in the context's state
    tool_context.state["retrieved_data"] = db_agent_output
    return db_agent_output


async def call_concierge_agent(
    question: str,
    tool_context: ToolContext,
):
    """
    After getting data with call_db_agent, use this tool to get travel advice, opinions, or recommendations.
    """
    # Import locally to prevent circular dependency loop
    from agents import concierge_agent
    
    print("--- TOOL CALL: call_concierge_agent ---")
    # Retrieve the data fetched by the previous tool
    input_data = tool_context.state.get("retrieved_data", "No data found.")

    # Formulate a new prompt for the concierge, giving it the data context
    question_with_data = f"""
    Context: The database returned the following data: {input_data}

    User's Request: {question}
    """

    agent_tool = AgentTool(agent=concierge_agent)
    concierge_output = await agent_tool.run_async(
        args={"request": question_with_data}, tool_context=tool_context
    )
    return concierge_output