import asyncio
import os
from dotenv import load_dotenv
from google.adk.runners import Runner
from google.adk.sessions import InMemorySessionService, Session
from google.genai.types import Content, Part
from agents import foodie_agent, day_trip_agent, router_agent, weekend_guide_agent, find_and_navigate_agent
from google.adk.agents import Agent
import random
import re

# Load variables from .env
load_dotenv()

session_service = InMemorySessionService()
my_user_id = "local_adventurer_001"

async def run_query(agent, query: str):
    session = await session_service.create_session(app_name=agent.name, user_id=my_user_id)
    print(f"\n🚀 Querying {agent.name} (Session: {session.id})...")
    
    runner = Runner(agent=agent, session_service=session_service, app_name=agent.name)
    
    async for event in runner.run_async(
        user_id=my_user_id,
        session_id=session.id,
        new_message=Content(parts=[Part(text=query)], role="user")
    ):
        if event.is_final_response():
            print("\n--- Agent Response ---")
            print(event.content.parts[0].text)
            print("----------------------")

async def run_agent_query(agent: Agent, query: str, session: Session, user_id: str, is_router: bool = False):
    """Initializes a runner and executes a query for a given agent and session."""
    print(f"\n🚀 Running query for agent: '{agent.name}' in session: '{session.id}'...")

    runner = Runner(
        agent=agent,
        session_service=session_service,
        app_name=agent.name
    )

    final_response = ""
    try:
        async for event in runner.run_async(
            user_id=user_id,
            session_id=session.id,
            new_message=Content(parts=[Part(text=query)], role="user")
        ):
            if not is_router:
                # Let's see what the agent is thinking!
                print(f"EVENT: {event}")
            if event.is_final_response():
                final_response = event.content.parts[0].text
    except Exception as e:
        final_response = f"An error occurred: {e}"

    if not is_router:
     print("\n" + "-"*50)
     print("✅ Final Response:")
     print(final_response)
     print("-"*50 + "\n")

    return final_response

async def run_agent_query_with_retry(
    agent: Agent,
    query: str,
    session: Session,
    user_id: str,
    is_router: bool = False,
    max_retries: int = 5,
    initial_delay: float = 2.0,
    backoff_factor: float = 2.0
):
    """Runs agent queries with an exponential backoff retry mechanism to mitigate 429 rate limit issues."""
    print(f"\n🚀 Running query (with retry backoff) for agent: '{agent.name}'...")
    
    delay = initial_delay
    for attempt in range(1, max_retries + 1):
        try:
            runner = Runner(
                agent=agent,
                session_service=session_service,
                app_name=agent.name
            )
            final_response = ""
            async for event in runner.run_async(
                user_id=user_id,
                session_id=session.id,
                new_message=Content(parts=[Part(text=query)], role="user")
            ):
                if not is_router:
                    print(f"EVENT: {event}")
                if event.is_final_response():
                    final_response = event.content.parts[0].text
            
            if not is_router:
                print("\n" + "-"*50)
                print("✅ Final Response:")
                print(final_response)
                print("-"*50 + "\n")
            return final_response
            
        except Exception as e:
            is_rate_limit = "429" in str(e) or "ResourceExhausted" in str(e)
            if is_rate_limit and attempt < max_retries:
                # Apply exponential backoff with jitter
                jitter = random.uniform(0.5, 1.5)
                sleep_time = delay * jitter
                print(f"⚠️ Hit rate limit (429). Retrying attempt {attempt}/{max_retries} in {sleep_time:.2f} seconds...")
                await asyncio.sleep(sleep_time)
                delay *= backoff_factor
            else:
                print(f"❌ Execution failed on attempt {attempt}: {e}")
                if attempt == max_retries:
                    raise e

async def run_sequential_app():
    queries = [
        "I want to eat the best sushi in Palo Alto.", # Should go to foodie_agent
        "Are there any cool outdoor concerts this weekend?", # Should go to weekend_guide_agent
        "Find me the best sushi in Palo Alto and then tell me how to get there from the Caltrain station." # Should trigger the SequentialAgent
    ]

    for query in queries:
        print(f"\n{'='*60}\n🗣️ Processing New Query: '{query}'\n{'='*60}")

        # 1. Ask the Router Agent to choose the right agent or workflow
        router_session = await session_service.create_session(app_name=router_agent.name, user_id=my_user_id)
        print("🧠 Asking the router agent to make a decision...")
        chosen_route = await run_agent_query(router_agent, query, router_session, my_user_id, is_router=True)
        chosen_route = chosen_route.strip().replace("'", "")
        print(f"🚦 Router has selected route: '{chosen_route}'")

        # 2. Execute the chosen route
        # This logic is now much simpler! The SequentialAgent is treated just like any other worker.
        if chosen_route in worker_agents:
            worker_agent = worker_agents[chosen_route]
            print(f"--- Handing off to {worker_agent.name} ---")
            worker_session = await session_service.create_session(app_name=worker_agent.name, user_id=my_user_id)
            await run_agent_query(worker_agent, query, worker_session, my_user_id)
            print(f"--- {worker_agent.name} Complete ---")
        else:
            print(f"🚨 Error: Router chose an unknown route: '{chosen_route}'")

worker_agents = {
    "day_trip_agent": day_trip_agent,
    "foodie_agent": foodie_agent,
    "weekend_guide_agent": weekend_guide_agent,
    "find_and_navigate_agent": find_and_navigate_agent, # Add the new sequential agent
}


if __name__ == "__main__":
    asyncio.run(run_sequential_app())